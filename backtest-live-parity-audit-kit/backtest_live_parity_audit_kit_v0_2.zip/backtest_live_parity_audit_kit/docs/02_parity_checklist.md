# Backtest-to-Live Parity Checklist

Use this checklist before trusting a live/paper bot result.

## A. Data parity

- [ ] Same symbol/instrument.
- [ ] Same session window.
- [ ] Same timezone.
- [ ] Same bid/ask/mid-price basis.
- [ ] Same spread/cost assumptions.
- [ ] Same candle/tick source or documented difference.
- [ ] Same rounding precision.

## B. Signal parity

- [ ] Signal is evaluated at the same interval in backtest and live.
- [ ] Live signal does not change inside a candle/bucket unless backtest does too.
- [ ] Buy and sell logic remain distinct if the strategy was built that way.
- [ ] Bid-side and ask-side inputs are not accidentally collapsed into mid-price.
- [ ] Thresholds/parameters exactly match.
- [ ] Warmup/history length exactly matches.

## C. Execution parity

- [ ] Entry timing matches expected rules.
- [ ] Entry price basis matches expected rules.
- [ ] TP/SL checks happen at the same frequency.
- [ ] Stop/target behavior is identical in live and backtest.
- [ ] Order cancellation/retry logic is logged.
- [ ] Duplicate orders are impossible or explicitly detected.

## D. State/session parity

- [ ] State file names are unique per strategy/symbol/session.
- [ ] Multiple runners cannot overwrite each other.
- [ ] Restart/resume behavior is logged.
- [ ] Param mismatch forces a clean state or blocks resume.
- [ ] Daily/session target locks further entries when reached.

## E. Evidence quality

- [ ] Every trade has a unique ID.
- [ ] Every signal has a timestamp.
- [ ] Every order decision has a reason.
- [ ] Every exit has an exit reason.
- [ ] Live log and replay output can be compared without manual guessing.
- [ ] Audit result is written to a durable report.
