# Disclaimer

The Backtest-to-Live Parity Audit Kit is an educational and technical quality-assurance resource for trading-system developers.

It does not provide financial advice, investment advice, trading signals, portfolio recommendations, or guarantees of profit. Any examples are for technical illustration of logging, replay, execution, and audit workflows only.

Trading involves risk. Users are responsible for their own systems, decisions, compliance obligations, and financial outcomes.

Async audit reviews are limited to technical comparison of supplied logs/configuration and do not determine whether a strategy should be traded with real money.
