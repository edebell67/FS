# Example Audit Report

## Summary

**Classification:** Red

The live bot did not behave close enough to the replay/backtest to justify scaling. The largest issues were trade-count drift, intra-bucket signal changes, and mismatched TP/SL monitoring.

## Inputs reviewed

- Backtest period: example live session
- Live period: same session
- Symbol: GBP example
- Strategy type: fixed-interval threshold strategy
- Price basis: bid/ask cluster logic

## Headline comparison

- Backtest net result: +200.6 pips
- Live net result: +76.0 pips
- Difference: material
- Classification: unacceptable drift

## Likely causes

1. **Intra-bucket signal noise**
   - Backtest only evaluated stable bucket results.
   - Live engine reacted to signal-building noise before the bucket completed.

2. **TP/SL enforcement mismatch**
   - Backtest model checked fixed exits consistently.
   - Live loop did not enforce identical monitoring frequency/logic.

3. **Price-basis mismatch risk**
   - Strategy logic relied on separate bid/ask behavior.
   - Collapsing to mid-price would change the strategy definition.

4. **State collision risk**
   - Multiple runners must not share state files.
   - State filenames should include strategy/comment/symbol/session identifiers.

## Remediation checklist

- [ ] Lock signal evaluation to the same interval used by replay/backtest.
- [ ] Verify TP/SL checks with tick-level or equivalent live monitoring.
- [ ] Preserve bid/ask logic where the strategy depends on it.
- [ ] Use unique state files per strategy/symbol/session.
- [ ] Replay the captured live price file and compare live vs replay within the acceptance threshold.

## Deployment recommendation

Do not scale until a fresh live/replay audit shows:

- trade count drift under 5%
- net result drift explainable and bounded
- no duplicate orders
- no opposite-side mismatches
- TP/SL exits matching the specification
