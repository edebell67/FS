# Deployment Readiness Scorecard

Score each section 0–2.

- 0 = missing / failed
- 1 = partial / unclear
- 2 = strong evidence

## Scoring

### Data parity
- Same symbol/session/timezone: __ / 2
- Same price basis and rounding: __ / 2
- Same cost/spread/slippage assumptions: __ / 2

### Signal parity
- Same interval/bucket logic: __ / 2
- Same thresholds/parameters: __ / 2
- No unexplained intra-bucket drift: __ / 2

### Execution parity
- Entry behavior matches: __ / 2
- TP/SL behavior matches: __ / 2
- No duplicate/missed order evidence: __ / 2

### State control
- Unique state per runner: __ / 2
- Restart/resume is safe: __ / 2
- Daily/session target behavior verified: __ / 2

### Evidence quality
- Logs are complete enough to audit: __ / 2
- Trade-by-trade comparison produced: __ / 2
- Differences are explained: __ / 2

## Result bands

- 25–30: Green — ready for cautious further testing.
- 16–24: Amber — fix evidence gaps before scaling.
- 0–15: Red — do not scale; live behavior is not proven.

## Final classification

- [ ] Green
- [ ] Amber
- [ ] Red

Notes:

```text
<write findings here>
```
