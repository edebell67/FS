# Quick Start: 1-Day Backtest-to-Live Parity Audit

## Goal

Prove whether your live or paper trading bot is executing the same system you backtested.

This audit does **not** tell you whether a strategy will make money. It tells you whether your test evidence and live behavior match closely enough to trust further experimentation.

## Required inputs

1. Backtest trade log: CSV or JSON converted to rows.
2. Live/paper trade log: CSV or JSON converted to rows.
3. Strategy configuration used in both runs.
4. Price source description: broker feed, capture file, replay file, candle data, or tick data.
5. Timezone used by every file.

## Minimum trade-log columns

- `trade_id`
- `entry_time`
- `exit_time`
- `symbol`
- `side`
- `entry_price`
- `exit_price`
- `quantity` or `size`
- `exit_reason`
- `net_pips` or `net_points`

If your logs do not contain these fields, your first audit result is: **logging is insufficient**.

## 1-day audit process

### Step 1 — Freeze the config

Save a copy of the exact live config and backtest config. Check:

- symbol naming
- bid/ask/mid-price assumptions
- spread/cost/slippage assumptions
- polling interval
- candle/bucket interval
- TP/SL logic
- timezone
- session hours
- state/session reset behavior

### Step 2 — Capture live behavior

Run the bot in live or paper mode while writing an execution log for every signal decision, order decision, TP/SL decision, and state transition.

### Step 3 — Replay the same price period

Run your backtest/replay over the exact live period using the same price source where possible.

### Step 4 — Compare trade-by-trade

Use `templates/live_vs_backtest_template.csv` or `scripts/compare_trades.py`.

Primary metrics:

- trade count difference
- side mismatch count
- missed trade count
- duplicate trade count
- median entry-time drift
- average entry-price drift
- exit reason mismatch count
- net result difference

### Step 5 — Classify the outcome

- **Green:** live and replay are materially aligned.
- **Amber:** small differences exist but are explainable and bounded.
- **Red:** live behavior does not match replay/backtest; do not scale.

## Suggested acceptance threshold

For early audits, treat these as maximum acceptable drift:

- trade count difference: under 5%
- net result difference: under 5–10%
- zero unexplained duplicate orders
- zero unexplained opposite-side entries
- all TP/SL/target exits explainable

Use stricter thresholds before risking larger capital.
