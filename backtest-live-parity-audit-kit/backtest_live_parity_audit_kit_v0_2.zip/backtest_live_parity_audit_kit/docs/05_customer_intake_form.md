# Async Audit Intake Form

## Contact

- Name:
- Email:
- Trading platform/broker:
- Bot framework/language:

## Strategy context

- Instrument/symbol:
- Session/time period:
- Timezone:
- Bar/tick interval:
- Backtest engine/tool:
- Live/paper execution engine/tool:

## Files attached

- [ ] Backtest trade log
- [ ] Live/paper trade log
- [ ] Strategy configuration
- [ ] Price capture/replay file
- [ ] Screenshot or summary output

## Known problem

What looks wrong?

```text

```

## Safety scope

I understand this audit is technical QA of system behavior. It is not investment advice, a signal service, or a recommendation to place trades.

- [ ] I agree
