#!/usr/bin/env python3
"""Generate a Markdown parity audit report from compare_trades.py JSON output."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def classify(summary: dict) -> str:
    if summary["unmatched_live_trades"] or summary["unmatched_backtest_trades"]:
        return "Red"
    if summary["trade_count_diff_pct"] <= 5 and summary["net_diff_pct"] <= 10:
        return "Green"
    if summary["trade_count_diff_pct"] <= 10 and summary["net_diff_pct"] <= 20:
        return "Amber"
    return "Red"


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--comparison", required=True, type=Path)
    p.add_argument("--out", required=True, type=Path)
    args = p.parse_args()

    data = json.loads(args.comparison.read_text(encoding="utf-8"))
    s = data["summary"]
    rating = classify(s)
    md = f"""# Backtest-to-Live Parity Audit Report

## Classification

**{rating}**

## Summary metrics

- Backtest trades: {s['backtest_trades']}
- Live trades: {s['live_trades']}
- Matched trades: {s['matched_trades']}
- Unmatched backtest trades: {s['unmatched_backtest_trades']}
- Unmatched live trades: {s['unmatched_live_trades']}
- Backtest net pips/points: {s['backtest_net_pips']}
- Live net pips/points: {s['live_net_pips']}
- Net difference: {s['net_pips_difference']}
- Trade-count difference %: {s['trade_count_diff_pct']}
- Net difference %: {s['net_diff_pct']}

## Interpretation

Green means the supplied logs are materially aligned under the configured thresholds. Amber means differences exist and should be explained before scaling. Red means live behavior is not proven to match backtest/replay behavior.

## Recommended next checks

- Confirm timezone and symbol naming.
- Confirm bid/ask/mid-price assumptions.
- Confirm live signal timing matches backtest timing.
- Confirm TP/SL evaluation frequency and price basis.
- Confirm no duplicate state/order files across concurrent runners.

## Disclaimer

This is a technical QA report only. It is not investment advice, trading advice, or a recommendation to place trades.
"""
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(md, encoding="utf-8")
    print(args.out)


if __name__ == "__main__":
    main()
