#!/usr/bin/env python3
"""Compare live and backtest trade logs.

Expected CSV columns:
trade_id, entry_time, exit_time, symbol, side, entry_price, exit_price, exit_reason, net_pips

Matching is intentionally simple for v0.1: symbol + side + nearest entry_time.
"""
from __future__ import annotations

import argparse
import csv
import json
from datetime import datetime, timezone
from pathlib import Path


def parse_time(value: str) -> datetime:
    value = (value or "").strip()
    if not value:
        raise ValueError("empty timestamp")
    value = value.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        # common fallback without timezone
        return datetime.strptime(value, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)


def read_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    for i, row in enumerate(rows, start=1):
        row["_row"] = i
        row["_entry_dt"] = parse_time(row.get("entry_time", ""))
        row["_net"] = float(row.get("net_pips") or 0)
        row["_entry_price"] = float(row.get("entry_price") or 0)
    return rows


def seconds(a: datetime, b: datetime) -> float:
    return abs((a - b).total_seconds())


def compare(backtest: list[dict], live: list[dict], max_time_diff_seconds: int) -> dict:
    unmatched_live = set(range(len(live)))
    matches = []
    unmatched_backtest = []

    for b in backtest:
        candidates = []
        for idx in list(unmatched_live):
            l = live[idx]
            if (b.get("symbol") or "").strip() != (l.get("symbol") or "").strip():
                continue
            if (b.get("side") or "").strip().lower() != (l.get("side") or "").strip().lower():
                continue
            diff = seconds(b["_entry_dt"], l["_entry_dt"])
            if diff <= max_time_diff_seconds:
                candidates.append((diff, idx, l))
        if not candidates:
            unmatched_backtest.append(b)
            continue
        diff, idx, l = min(candidates, key=lambda x: x[0])
        unmatched_live.remove(idx)
        matches.append({
            "backtest_trade_id": b.get("trade_id") or b["_row"],
            "live_trade_id": l.get("trade_id") or l["_row"],
            "symbol": b.get("symbol"),
            "side": b.get("side"),
            "entry_time_diff_seconds": diff,
            "entry_price_diff": l["_entry_price"] - b["_entry_price"],
            "exit_reason_match": (b.get("exit_reason") or "").strip().lower() == (l.get("exit_reason") or "").strip().lower(),
            "net_pips_diff": l["_net"] - b["_net"],
        })

    backtest_net = sum(r["_net"] for r in backtest)
    live_net = sum(r["_net"] for r in live)
    trade_count_diff_pct = 0 if not backtest else abs(len(live) - len(backtest)) / len(backtest) * 100
    net_diff_pct = 0 if backtest_net == 0 else abs(live_net - backtest_net) / abs(backtest_net) * 100

    return {
        "summary": {
            "backtest_trades": len(backtest),
            "live_trades": len(live),
            "matched_trades": len(matches),
            "unmatched_backtest_trades": len(unmatched_backtest),
            "unmatched_live_trades": len(unmatched_live),
            "backtest_net_pips": round(backtest_net, 4),
            "live_net_pips": round(live_net, 4),
            "net_pips_difference": round(live_net - backtest_net, 4),
            "trade_count_diff_pct": round(trade_count_diff_pct, 2),
            "net_diff_pct": round(net_diff_pct, 2),
        },
        "matches": matches,
        "unmatched_backtest": [{"trade_id": r.get("trade_id"), "row": r["_row"]} for r in unmatched_backtest],
        "unmatched_live": [{"trade_id": live[i].get("trade_id"), "row": live[i]["_row"]} for i in sorted(unmatched_live)],
    }


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--backtest", required=True, type=Path)
    p.add_argument("--live", required=True, type=Path)
    p.add_argument("--out", required=True, type=Path)
    p.add_argument("--max-time-diff-seconds", type=int, default=300)
    args = p.parse_args()

    result = compare(read_csv(args.backtest), read_csv(args.live), args.max_time_diff_seconds)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result["summary"], indent=2))


if __name__ == "__main__":
    main()
