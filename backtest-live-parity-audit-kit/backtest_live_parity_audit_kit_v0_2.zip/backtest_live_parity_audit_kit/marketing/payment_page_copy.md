# Payment Page Copy

## Product name

Backtest-to-Live Parity Audit Kit

## Short description

A technical QA kit for finding why a live or paper trading bot does not match its backtest.

## Price

£79

## Full description

Your bot can pass a backtest and still behave differently live.

This kit gives you a structured way to compare live/paper execution against backtest or replay output, identify drift, and decide whether your logs are strong enough to trust further testing.

Includes:

- Quick-start parity audit guide
- Live/backtest mismatch checklist
- Deployment readiness scorecard
- CSV comparison template
- Python comparison scripts
- Example audit report
- Async audit intake form
- Disclaimer and safe-use notes

This is not a signal service or investment product. It is a technical QA workflow for trading-system developers.

## Upsell copy

### Add a 48-hour async technical audit review — £199 total

Send your backtest log, live/paper log, and config. Receive a written technical discrepancy report with likely causes, evidence gaps, and a deployability classification.

Limited founder audit slots may be offered separately at £299.
