# Launch Checklist

## Before payment page

- [ ] Ed approves public positioning.
- [ ] Ed approves disclaimer.
- [ ] Ed selects payment platform: Gumroad, Lemon Squeezy, Stripe Payment Link, or existing checkout.
- [ ] Product ZIP generated.
- [ ] Test download works.

## Before public posting

- [ ] Ed approves first public copy set.
- [ ] Confirm X posting route/account.
- [ ] Confirm whether Reddit posting is allowed manually or via browser only.
- [ ] Record links and post IDs after publishing.

## Launch metrics

Track daily:

- page views
- checkout views
- sales
- refund requests
- qualified replies
- audit slot requests
- best-performing post angle

## 60-day target

Target mix:

- 20 x £79 = £1,580
- 5 x £199 = £995
- 2 x £299 = £598
- Total = £3,173
