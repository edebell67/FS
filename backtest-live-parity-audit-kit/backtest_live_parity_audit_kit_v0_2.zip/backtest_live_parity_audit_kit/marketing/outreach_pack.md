# Outreach Pack

## X posts

### Post 1

A trading bot can pass a backtest and still fail live.

Not because the strategy changed.

Because the engine changed.

Common causes:
- signal changes inside the candle
- TP/SL checked differently live
- bid/ask logic collapsed into mid-price
- duplicate state files
- polling interval mismatch
- missed/duplicated orders

Before scaling, run a live/backtest parity audit.

### Post 2

If your backtest says +200 and live says +76, do not start by optimizing parameters.

Start by proving the live engine is executing the same logic as the replay.

Trade count, entry timing, price basis, TP/SL checks, and state files matter.

### Post 3

Most bot dashboards show P&L.

They should also show evidence quality:

- did live match replay?
- were any trades missed?
- were any orders duplicated?
- did TP/SL fire for the same reason?
- did state resume safely?

Without that, you are debugging blind.

### Post 4

Backtest/live parity checklist:

1. Same timezone
2. Same symbol
3. Same bid/ask/mid basis
4. Same spread/cost model
5. Same signal interval
6. Same TP/SL checks
7. Unique state per runner
8. No duplicate orders
9. Trade-by-trade diff

Skip this and your bot may be testing a different system live.

## Reddit discussion draft

Title:
How are people comparing live bot execution against backtest results?

Body:
For people running trading bots live or in paper trading:

How are you checking whether the live bot is actually behaving like the backtest?

I’m not talking about whether the strategy is profitable. I mean basic parity:

- same number of trades?
- same entry side?
- similar entry time?
- same TP/SL behaviour?
- same bid/ask assumptions?
- same candle/bucket boundary logic?
- no duplicate state/order issues?

I’ve seen cases where the backtest looked fine but live behaviour drifted badly because the live engine was evaluating signals differently.

Curious what people are using to audit this.

## Direct outreach DM

Hi — noticed you build/share trading bot content.

I’m launching a small technical QA kit for algo traders: it helps compare live/paper bot logs against backtest/replay output to find execution drift, missed trades, duplicate orders, TP/SL mismatches, and state issues.

It is not signals or strategy advice — just live/backtest parity auditing.

Would you be open to a free review copy? If useful, I can also set up an affiliate link.
