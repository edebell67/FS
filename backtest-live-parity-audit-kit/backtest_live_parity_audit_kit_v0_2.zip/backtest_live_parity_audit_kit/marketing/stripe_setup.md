# Stripe Payment Link Setup

Ed owns the Stripe account and money flow. Hermes prepares copy, products, redirect targets, and launch assets.

## Products to create

### 1. Backtest-to-Live Parity Audit Kit

- Price: £79 GBP
- Type: One-time payment
- Button label on landing page: `Buy the Audit Kit — £79`
- Product description:

```text
A technical QA kit for finding why a live or paper trading bot does not match its backtest. Includes audit guide, checklist, scorecard, CSV template, Python comparison scripts, example report, and safe-use disclaimer. Not investment advice or a signal service.
```

Success URL after payment:

```text
https://YOUR_DOMAIN/download.html?session_id={CHECKOUT_SESSION_ID}
```

Temporary fallback if no domain yet:

```text
Thanks — your kit will be emailed manually within 24 hours.
```

### 2. Kit + 48h Async Audit Review

- Price: £199 GBP
- Type: One-time payment
- Button label: `Get Kit + Audit Review — £199`
- Product description:

```text
Includes the Backtest-to-Live Parity Audit Kit plus a 48-hour async technical audit review of supplied backtest/live logs and configuration. The review identifies execution drift, evidence gaps, and likely technical mismatch causes. Not investment advice.
```

Success URL:

```text
https://YOUR_DOMAIN/audit-intake.html?session_id={CHECKOUT_SESSION_ID}
```

### 3. Founder Audit Slot

- Price: £299 GBP
- Type: One-time payment
- Button label: `Book Founder Audit Slot — £299`
- Product description:

```text
Limited founder technical audit slot for live/backtest parity mismatch. Includes the kit plus a deeper written review of logs, config, and execution behavior. Technical QA only. Not investment advice.
```

Success URL:

```text
https://YOUR_DOMAIN/audit-intake.html?session_id={CHECKOUT_SESSION_ID}&tier=founder
```

## After Stripe creates links

Replace these placeholders in `public/index.html`:

- `STRIPE_KIT_LINK`
- `STRIPE_AUDIT_LINK`
- `STRIPE_FOUNDER_LINK`

## Optional Stripe settings

- Collect customer email: yes.
- Collect billing address: optional, use Stripe tax/account defaults.
- Allow promotion codes: no for launch v0.1.
- Quantity adjustable: no.
- Customer message: include disclaimer line.
- Terms checkbox: enable if available and link to disclaimer.

## Required from Ed

1. Confirm Stripe account is live and can accept GBP.
2. Create the three payment links.
3. Send Hermes the three `https://buy.stripe.com/...` URLs.
4. Confirm final public domain or temporary hosting route.
