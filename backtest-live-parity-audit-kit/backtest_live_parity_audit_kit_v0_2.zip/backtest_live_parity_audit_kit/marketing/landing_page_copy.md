# Landing Page Copy

## Hero

### Your backtest is not enough. Prove your live bot matches it.

A practical audit kit for algo traders and bot developers who need to find why live/paper execution drifts from backtest results.

**CTA:** Get the Backtest-to-Live Parity Audit Kit — £79

## Pain section

Your strategy can look fine in a backtest and still fail live because the engine behaves differently:

- signals update inside the candle/bucket
- TP/SL is checked differently live
- bid/ask logic is not the same as replay
- state files collide across runners
- live logs are too weak to diagnose missed or duplicate orders
- the backtest used one price basis and live used another

This kit helps you audit the execution system, not guess.

## What you get

- 1-day parity audit guide
- live vs backtest checklist
- deployment readiness scorecard
- spreadsheet comparison template
- Python comparison scripts
- example audit report
- async audit intake form
- technical disclaimer and safe framing

## Who it is for

- Python backtesters
- MT4/MT5 EA users
- TradingView webhook bot users
- retail algo traders
- bot developers debugging live/paper mismatch

## Who it is not for

- people looking for signals
- people looking for guaranteed returns
- people wanting someone to trade for them

## CTA

**Get the kit — £79**

Optional: add a 48-hour async technical audit review.

## Disclaimer block

This product is a technical QA resource. It does not provide investment advice, trading signals, or profit guarantees.
