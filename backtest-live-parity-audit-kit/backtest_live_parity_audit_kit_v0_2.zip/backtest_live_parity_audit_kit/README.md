# Backtest-to-Live Parity Audit Kit

A technical QA kit for traders and bot developers who need to prove whether a live/paper trading bot behaves like its backtest.

## Product positioning

**Core promise:** find why live execution drifts from backtest/replay results before scaling real money.

This is not a signal service, strategy recommendation, or investment product. It is an engineering audit workflow for trading-system behavior.

## Offer ladder

- Self-serve kit: £79
- Kit + async audit review: £199
- Founder audit slot: £299

## Contents

- `docs/01_quick_start.md` — run the audit in a day.
- `docs/02_parity_checklist.md` — checklist of common live/backtest mismatch causes.
- `docs/03_deployment_readiness_scorecard.md` — green/amber/red scoring rubric.
- `docs/04_example_audit_report.md` — anonymized example report structure.
- `docs/05_customer_intake_form.md` — intake questions for async audit customers.
- `docs/06_disclaimer.md` — legal/positioning disclaimer.
- `templates/live_vs_backtest_template.csv` — comparison spreadsheet starter.
- `scripts/compare_trades.py` — compare two trade logs.
- `scripts/generate_audit_report.py` — generate Markdown report from comparison output.
- `marketing/landing_page_copy.md` — landing-page copy.
- `marketing/payment_page_copy.md` — Gumroad/Lemon Squeezy copy.
- `marketing/outreach_pack.md` — X, Reddit, DM copy.
- `marketing/launch_checklist.md` — operational launch checklist.
- `marketing/stripe_setup.md` — exact Stripe Payment Link setup.
- `public/index.html` — static landing page with Stripe placeholders.
- `public/download.html` — post-payment kit delivery page.
- `public/audit-intake.html` — post-payment audit intake page.
